package ui;

import exceptions.RouteNotFoundException;
import model.Route;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Represents a command to edit a route
public class EditRouteCommand extends Command {
    ClickListener listener;
    Route route;

    // EFFECTS: constructs a command for editing a route
    public EditRouteCommand(JMenu menu, RouteLogApp app) {
        super("Edit Route", menu, app);
        listener = new ClickListener();
        addListener();
    }

    // MODIFIES: this
    // EFFECTS: adds a listener to the menu
    @Override
    protected void addListener() {
        menuItem.addActionListener(listener);
    }

    // Represents a listener for a menu
    private class ClickListener implements ActionListener {

        // EFFECTS: sets command to be on when "Edit Route" is clicked
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Edit Route")) {
                editRoute();
            }
        }
    }

    // Represents a listener for the add button
    private class AddButtonListener implements ActionListener {

        // EFFECTS: if "Add Step" is clicked, the route will add a step
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Add Step")) {
                addStepHere(route);
            }
        }
    }

    // Represents a listener for the delete button
    private class DeleteButtonListener implements ActionListener {

        // EFFECTS: if "Delete Step" is clicked, the route will delete a step
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Delete Step")) {
                deleteStepHere(route);
            }
        }
    }

    // MODIFIES: this
    // EFFECTS: edits steps of route with given name
    private void editRoute() {
        String routeName = JOptionPane.showInputDialog("Enter name of route to edit: ");
        try {
            this.route = log.findRoute(routeName);

            JButton add = new JButton("Add Step");
            JButton del = new JButton("Delete Step");
            add.addActionListener(new AddButtonListener());
            del.addActionListener(new DeleteButtonListener());
            Object[] buttons = {add,del};
            JOptionPane.showOptionDialog(null,"Edit Route",
                    "Add or Delete Step?",JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,null,buttons,buttons[0]);

        } catch (RouteNotFoundException e) {
            JOptionPane.showMessageDialog(null,"Not a valid route name...");
        }
    }

    // MODIFIES: route
    // EFFECTS: adds step at desired location
    private void addStepHere(Route r) {
        JTextField numField = new JTextField(5);
        JTextField dirField = new JTextField(5);
        JTextField strField = new JTextField(20);
        JTextField distField = new JTextField(20);

        JPanel stepPanel = new JPanel();
        stepPanel.add(new JLabel("Step Number: "));
        stepPanel.add(numField);
        stepPanel.add(new JLabel("Direction (north/south/east/west): "));
        stepPanel.add(dirField);
        stepPanel.add(new JLabel("Street Name: "));
        stepPanel.add(strField);
        stepPanel.add(new JLabel("Distance (metres): "));
        stepPanel.add(distField);

        int result = JOptionPane.showConfirmDialog(null, stepPanel, "Please enter a new step: ",
                JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            int orderNum = Integer.parseInt(numField.getText());
            int dist = Integer.parseInt(distField.getText());
            r.insertStep(orderNum, dirField.getText(), dist, strField.getText());
        }
    }

    // MODIFIES: route
    // EFFECTS: removes step from desired location
    private void deleteStepHere(Route r) {
        int orderNum = Integer.parseInt(JOptionPane.showInputDialog("Enter step number: "));
        r.removeStep(orderNum);
    }

}
