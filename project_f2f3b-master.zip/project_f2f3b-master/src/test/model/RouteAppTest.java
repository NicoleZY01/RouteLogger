package model;

import exceptions.DuplicateRouteNameException;
import exceptions.RouteNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.jxmapviewer.viewer.GeoPosition;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RouteAppTest {
    private Step d;
    private Route r;
    private RouteManager l;

    @BeforeEach
    public void runBefore() {
        d = new Step("North",5000, "Lynn Canyon");
        r = new Route("Route 1", new GeoPosition(0, 0));
        l = new RouteManager();
    }

    @Test
    public void testStep() {
        assertEquals(5000, d.getDistance());
        assertEquals("Lynn Canyon", d.getStreetName());
        assertEquals("North",d.getDirection());
    }

    @Test
    public void testRoute() {
        assertEquals("Route 1", r.name);
        assertEquals(0, r.steps.size());
        assertEquals(0,r.getStart().getLatitude());
        assertEquals(0,r.getStart().getLongitude());
    }

    @Test
    public void testAddStep() {
        r.addStep("East",1000, "Main Mall");
        assertEquals(1,r.getSteps().size());
    }

    @Test
    public void testRemoveOneStep() {
        r.addStep("East",1050, "East Mall");
        r.removeStep(1);
        assertEquals(0, r.steps.size());
    }

    @Test
    public void testRemoveOneStepZero() {
        r.addStep("East",1050, "East Mall");
        r.removeStep(0);
        assertEquals(1, r.getSteps().size());
    }

    @Test
    public void testRemoveStepNotThere() {
        r.addStep("East",1050, "East Mall");
        r.removeStep(2);
        assertEquals(1, r.getSteps().size());
    }

    @Test
    public void testRemoveMoreSteps() {
        r.addStep("West",1050, "East Mall");
        r.addStep("East",5610, "West 16th");
        r.addStep("North",800,"University Boulevard");
        r.removeStep(2);
        assertEquals(2, r.steps.size());
        assertEquals(2,r.getStep(2).getOrderNum());
    }

    @Test
    public void testInsertStepCorrectNum() {
        r.addStep("West",1050, "East Mall");
        r.addStep("East",5610, "West 16th");
        r.insertStep(2,"North",800,"University Boulevard");
        assertEquals(3, r.steps.size());
        assertEquals(3,r.getStep(3).getOrderNum());
    }

    @Test
    public void testInsertStepIncorrectNum() {
        r.addStep("West",1050, "East Mall");
        r.addStep("East",5610, "West 16th");
        r.insertStep(4,"North",800,"University Boulevard");
        assertEquals(3, r.steps.size());
        assertEquals(3,r.getStep(3).getOrderNum());
    }


    @Test
    public void testRename() {
        r.renameRoute("Route 2");
        assertEquals("Route 2",r.getName());
    }

    @Test
    public void testLengthOneDirection(){
        r.addStep("North",1000,"Cambie");
        assertEquals(1000,r.length());
    }

    @Test
    public void testLengthMoreDirections(){
        r.addStep("North",1000,"Cambie");
        r.addStep("West",1050, "East Mall");
        r.addStep("East",5610, "West 16th");
        assertEquals(1000+1050+5610,r.length());
    }

    @Test
    public void testNumberStep() {
        r.addStep("North",1000,"Cambie");
        assertEquals(1,r.getStep(1).getOrderNum());
    }

    @Test
    public void testAddRouteNoDuplicateName() {
        r.addStep("North",1000,"Cambie");
        try {
            l.addRoute(r);
            assertEquals(1,l.size());
            List<Route> lr = new ArrayList<>();
            lr.add(r);
            assertEquals(lr,l.getRoutes());
        } catch (DuplicateRouteNameException e) {
            fail("DuplicateRouteNameException thrown");
        }
    }

    @Test
    public void testAddRouteDuplicateName() {
        r.addStep("North",1000,"Cambie");
        try {
            l.addRoute(r);
            assertEquals(1,l.size());
            Route route = new Route("Route 1", new GeoPosition(0, 0));
            l.addRoute(route);
            fail("DuplicateRouteNameException not thrown");
        } catch (DuplicateRouteNameException e) {
            //
        }
    }

    @Test
    public void testRemoveRoute() {
        r.addStep("North", 1000, "Cambie");
        try {
            l.addRoute(r);
            assertEquals(1, l.size());
            l.removeRoute(r);
            assertEquals(0, l.size());
        } catch (DuplicateRouteNameException e) {
            fail("DuplicateRouteNameException thrown");
        }
    }

    @Test
    public void testFindRouteNothingThrown() {
        r.addStep("North",1000,"Cambie");
        try {
            l.addRoute(r);
            Route r1 = l.findRoute("Route 1");
            assertEquals(r,r1);
        } catch (DuplicateRouteNameException e) {
            fail("DuplicateRouteNameException thrown");
        } catch (RouteNotFoundException e) {
            fail("RouteNotFoundException thrown");
        }
    }

    @Test
    public void testRouteNotFoundExceptionThrown() {
        r.addStep("North",1000,"Cambie");
        try {
            l.addRoute(r);
            l.findRoute("Route 2");
            fail("RouteNotFoundException not thrown");
        } catch (DuplicateRouteNameException e) {
            fail("DuplicateRouteNameException thrown");
        } catch (RouteNotFoundException e) {
            //
        }
    }

}