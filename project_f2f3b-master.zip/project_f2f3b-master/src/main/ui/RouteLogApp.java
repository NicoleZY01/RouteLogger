package ui;

import exceptions.DuplicateRouteNameException;
import model.RouteManager;
import persistence.JsonReader;
import persistence.JsonWriter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

// Represents the route log application
public class RouteLogApp {
    private static final String JSON_STORE = "./data/routemanager.json";
    private final JsonReader jsonReader;
    private final JsonWriter jsonWriter;
    private RouteManager log;
    private JMenu menu;
    private List<Command> commands;
    private JMenuItem load;
    private JMenu origin;
    private Map map;

    // EFFECTS: creates an empty running route log
    public RouteLogApp() {
        jsonReader = new JsonReader(JSON_STORE);
        jsonWriter = new JsonWriter(JSON_STORE);
        log = new RouteManager();
        commands = new ArrayList<>();
        map = new Map();
        runRoute();
    }

    // MODIFIES: this
    // EFFECTS: processes user input
    // Modeled off of the TellerApp example found at https://github.students.cs.ubc.ca/CPSC210/TellerApp.git
    private void runRoute() {
        initGraphics();
    }

    // EFFECTS: draws the JFrame where app will operate
    private void initGraphics() {
        JFrame frame = new JFrame();
        frame.setLayout(new BorderLayout());
        frame.setMinimumSize(new Dimension(1000, 800));

        JMenuBar menuBar = new JMenuBar();
        menu = new JMenu("File");
        makeOriginMenu();
        createMenu(menu, origin);

        menuBar.add(menu);
        menuBar.add(origin);
        frame.setJMenuBar(menuBar);

        frame.getContentPane().add(map.getMapViewer());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // MODIFIES: this
    // EFFECTS: makes a menu called origin
    private void makeOriginMenu() {
        origin = new JMenu("Origin");
        JMenuItem setOrigin = new JMenuItem("Set Origin");
        JMenuItem done = new JMenuItem("Done");
        done.setVisible(false);
        origin.add(setOrigin);
        origin.add(done);
        origin.setVisible(false);
    }

    // EFFECTS: a helper method that declares and instantiates all command options
    private void createMenu(JMenu menu, JMenu origin) {
        loadCommand(menu);
        AddRouteCommand c1 = new AddRouteCommand(menu, this, origin, map);
        commands.add(c1);
        DeleteRouteCommand c2 = new DeleteRouteCommand(menu, this);
        commands.add(c2);
        EditRouteCommand c3 = new EditRouteCommand(menu, this);
        commands.add(c3);
        RenameRouteCommand c4 = new RenameRouteCommand(menu, this);
        commands.add(c4);
        ShowAllRoutesCommand c5 = new ShowAllRoutesCommand(menu, this, map.getMapViewer());
        commands.add(c5);
        FindRouteLengthCommand c6 = new FindRouteLengthCommand(menu, this);
        commands.add(c6);
        SaveRouteCommand c7 = new SaveRouteCommand(menu, this, jsonWriter);
        commands.add(c7);
        QuitCommand c8 = new QuitCommand(menu, this);
        commands.add(c8);
    }

    // EFFECTS: returns a log of routes
    public RouteManager getLog() {
        return log;
    }

    // MODIFIES: menu
    // EFFECTS: adds load to menu
    private void loadCommand(JMenu menu) {
        load = new JMenuItem("Load");
        ClickListener listener = new ClickListener();
        load.addActionListener(listener);
        menu.add(load);
    }

    // EFFECTS: loads route manager from file
    private void loadRouteManager() throws DuplicateRouteNameException {
        try {
            this.log = jsonReader.read();
            for (Command c : commands) {
                c.removeMenuItem(menu);
            }
            menu.remove(load);
            createMenu(menu, origin);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Cannot find this file...");
        }
    }

    // Represents a listener for a menu
    private class ClickListener implements ActionListener {

        // EFFECTS: sets command to be on when "Load" is clicked
        //          throws duplicate name exception if file contains routes with duplicate names
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Load")) {
                try {
                    loadRouteManager();
                } catch (DuplicateRouteNameException exception) {
                    JOptionPane.showMessageDialog(null, "ERROR: Duplicate name");
                }
            }
        }
    }

}




