package ui;

import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.OSMTileFactoryInfo;
import org.jxmapviewer.input.CenterMapListener;
import org.jxmapviewer.input.PanKeyListener;
import org.jxmapviewer.input.PanMouseInputListener;
import org.jxmapviewer.input.ZoomMouseWheelListenerCursor;
import org.jxmapviewer.viewer.DefaultTileFactory;
import org.jxmapviewer.viewer.GeoPosition;

import javax.swing.event.MouseInputListener;

// Code from JXMapViewer https://github.com/msteiger/jxmapviewer2.git
// Represents a map
public class Map {
    JXMapViewer mapViewer;
    DefaultTileFactory tileFactory;
    MouseInputListener mia;
    CenterMapListener cml;
    ZoomMouseWheelListenerCursor zm;
    PanKeyListener pk;

    // MODIFIES: this
    // EFFECTS: constructs a map centered on UBC
    public Map() {
        mapViewer = new JXMapViewer();
        OSMTileFactoryInfo info = new OSMTileFactoryInfo();
        tileFactory = new DefaultTileFactory(info);
        mapViewer.setTileFactory(tileFactory);

        tileFactory.setThreadPoolSize(8);

        GeoPosition ubc = new GeoPosition(49.2606,-123.2460);

        mapViewer.setZoom(4);
        mapViewer.setAddressLocation(ubc);
        createMouseInteractions();
    }

    // EFFECTS: returns a mapviewer
    public JXMapViewer getMapViewer() {
        return mapViewer;
    }

    // MODIFIES: this
    // EFFECTS: adds mouse interactions to the mapviewer
    public void createMouseInteractions() {
        mia = new PanMouseInputListener(mapViewer);
        mapViewer.addMouseListener(mia);
        mapViewer.addMouseMotionListener(mia);

        cml = new CenterMapListener(mapViewer);
        mapViewer.addMouseListener(cml);

        zm = new ZoomMouseWheelListenerCursor(mapViewer);
        mapViewer.addMouseWheelListener(zm);

        pk = new PanKeyListener(mapViewer);
        mapViewer.addKeyListener(pk);
    }

    // MODIFIES: this
    // EFFECTS: removes mouse interactions from map
    public void removeMouseInteractions() {
        mapViewer.removeMouseListener(mia);
        mapViewer.removeMouseMotionListener(mia);
        mapViewer.removeMouseListener(cml);
        mapViewer.removeMouseWheelListener(zm);
        mapViewer.removeKeyListener(pk);
    }
}
