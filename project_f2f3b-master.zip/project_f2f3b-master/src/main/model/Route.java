package model;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jxmapviewer.viewer.GeoPosition;

import java.util.ArrayList;
import java.util.List;

// Represents a route
public class Route {
    List<Step> steps;
    String name;
    GeoPosition start;

    // REQUIRES: distance > 0
    // EFFECTS: creates a new route
    public Route(String name, GeoPosition start) {
        this.name = name;
        this.steps = new ArrayList<>();
        this.start = start;
    }

    // MODIFIES: this
    // EFFECTS: adds a step to route
    public void addStep(String direction, int distance, String streetName) {
        Step s = new Step(direction, distance, streetName);
        Integer orderNum = steps.size() + 1;
        s.numberStep(orderNum);
        steps.add(s);
    }

    // REQUIRES: length of list > 0
    // MODIFIES: this
    // EFFECTS: inserts a step into steps at given order number
    public void insertStep(Integer orderNum, String dir, Integer dist, String streetName) {
        if (orderNum > steps.size() + 1) {
            addStep(dir,dist,streetName);
            System.out.println("Number of steps does not match given number.");
        } else {
            Step newStep = new Step(dir,dist,streetName);
            newStep.numberStep(orderNum);
            this.steps.add(orderNum - 1, newStep);
            updateOrderNum("insert", orderNum);
        }
    }

    // REQUIRES: length of list > 0
    // MODIFIES: this
    // EFFECTS: removes a step with given order number
    public void removeStep(Integer searchNum) {
        for (Step d : steps) {
            if (searchNum > 1) {
                if (d.orderNum == searchNum) {
                    updateOrderNum("delete", searchNum);
                    this.steps.remove(d);
                    break;
                }
            } else {
                if (d.orderNum == searchNum) {
                    this.steps.remove(d);
                    break;
                }
            }
        }
    }


    // MODIFIES: this
    // EFFECTS: renames the route
    public void renameRoute(String newName) {
        this.name = newName;
    }

    // EFFECTS: returns name of route
    public String getName() {
        return name;
    }

    // EFFECTS: returns name of route
    public List<Step> getSteps() {
        return steps;
    }

    // REQUIRES: step number > 0
    // EFFECTS: returns step with given step number
    public Step getStep(Integer num) {
        return steps.get(num - 1);
    }

    // EFFECTS: returns the start point
    public GeoPosition getStart() {
        return start;
    }

    // EFFECTS: returns total length of route
    public int length() {
        int length = 0;
        for (Step s : steps) {
            length = length + s.getDistance();
        }
        return length;
    }

    // REQUIRES: command must equal "insert" or "delete"
    // MODIFIES: this
    // EFFECTS: updates the order number of steps after given number
    public void updateOrderNum(String command, Integer num) {
        int lowerLimit = num;
        int upperLimit = steps.size();
        List<Step> updateList = new ArrayList<>(steps);
        this.steps = steps.subList(0, num);
        if (command.equals("insert")) {
            for (Step s : updateList.subList(lowerLimit,upperLimit)) {
                int newNum = s.getOrderNum() + 1;
                s.numberStep(newNum);
                this.steps.add(s);
            }
        } else {
            for (Step s : updateList.subList(lowerLimit,upperLimit)) {
                int newNum = s.getOrderNum() - 1;
                s.numberStep(newNum);
                this.steps.add(s);
            }
        }
    }

    // Code from JsonSerializationDemo https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    // EFFECTS: returns route as JSONObject
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("name",name);
        json.put("steps",stepsToJson());
        json.put("start",startToJson());
        return json;
    }

    // EFFECTS: returns steps as JSONArray
    public JSONArray stepsToJson() {
        JSONArray jsonArray = new JSONArray();

        for (Step s : steps) {
            jsonArray.put(s.toJson());
        }

        return jsonArray;
    }

    // EFFECTS: returns latitude and longitude as JSONObjects
    public JSONObject startToJson() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("latitude",start.getLatitude());
        jsonObject.put("longitude",start.getLongitude());

        return jsonObject;
    }

}
