package ui;

import persistence.JsonWriter;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

// Represents a command to save route
public class SaveRouteCommand extends Command {
    ClickListener listener;
    JsonWriter jsonWriter;

    // EFFECTS: constructs a command to save route
    public SaveRouteCommand(JMenu menu, RouteLogApp app, JsonWriter jsonWriter) {
        super("Save", menu, app);
        this.jsonWriter = jsonWriter;
        this.listener = new ClickListener();
        addListener();
    }

    // MODIFIES: this
    // EFFECTS: adds a listener to the menu
    @Override
    protected void addListener() {
        menuItem.addActionListener(listener);
    }

    // Code from JsonSerializationDemo https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    // MODIFIES: this
    // EFFECTS: saves current routes to file
    private void saveRouteManager() {
        try {
            jsonWriter.open();
            jsonWriter.write(log);
            jsonWriter.close();
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Cannot find this file...");
        }
    }

    // Represents a listener for a menu
    private class ClickListener implements ActionListener {

        // EFFECTS: sets command to be on when "Save" is clicked
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Save")) {
                saveRouteManager();
            }
        }
    }
}
