# CPSC210 Project: Training Route Log

A log is able to record information which can later be used to improve methods for finishing a task.
 This application will **keep track** of running routes designed by the user and show them on a map.
  People can **add** and **delete** the routes for training or recreational purposes. I like to run
  and hope to train for a half-marathon in the future, so this will allow me to design
  and visualize training plans.

## User Stories
- As a user, I want to be able to record steps for a route
- As a user, I want to be able to show a route on a map
- As a user, I want to be able to calculate the length of the route
- As a user, I want to be able to add and delete routes
- As a user, I want to be able to read steps for a route after adding them
- As a user, I want to be able to see all the routes I have added
- As a user, I want to be able to add and delete steps after making a route
- As a user, I want to be able to save routes
- As a user, I want to be able to load routes from previous save file

## Phase 4: Task 2
Test and design a class in the model package that is robust.
- In RouteManager, addRoute() throws a DuplicateRouteName exception
- In RouteManager, findRoute() throws a RouteNotFound exception
- In RouteLogApp, the private class ClickListener catches the DuplicateRouteName exception
- In AddRouteCommand, the private class DoneListener catches the DuplicateRouteName exception
- In JsonReader, read(), parseRouteManager(JSONObject json), addOldRoutes(RouteManager rm, JSONObject json), 
and addOldRoute(RouteManager rm, JSONObject json) all throw DuplicateRouteName exception
- In DeleteRouteCommand, deleteRoute() catches a RouteNotFound exception
- In EditRouteCommand, editRoute() catches a RouteNotFound exception
- In RenameRouteCommand, renameRoute() catches a RouteNotFound exception
- In FindRouteLengthCommand, routeDistance(String str) catches a RouteNotFound exception
- In ShowAllRoutesCommand, showAllRoutes() catches a RouteNotFound exception

## Phase 4: Task 3
If I had more time, I would reduce the coupling between RouteLogApp and Command.
I don't think there needs to be a bidirectional association there. I would associate Command with RouteManager instead.
I would consider making the FindRouteLengthCommand automatic. 
