package ui;

import exceptions.RouteNotFoundException;
import model.Route;
import model.Step;
import org.jxmapviewer.JXMapViewer;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

// Represents a command to show route names
public class ShowAllRoutesCommand extends Command {
    ClickListener listener;
    JXMapViewer map;

    // EFFECTS: constructs a command to show names of all routes
    public ShowAllRoutesCommand(JMenu menu, RouteLogApp app, JXMapViewer map) {
        super("Show All", menu, app);
        listener = new ClickListener();
        addListener();
        this.map = map;
    }

    // MODIFIES: this
    // EFFECTS: adds a listener to the menu
    @Override
    protected void addListener() {
        menuItem.addActionListener(listener);
    }

    // EFFECTS: constructs an option pane to select a route to print steps
    private void showAllRoutes() {
        map.setOverlayPainter(null);
        List<String> list = new ArrayList<>();
        for (Route r : log.getRoutes()) {
            list.add(r.getName());
        }
        Object[] choices = list.toArray();
        if (list.size() > 0) {
            String route = (String) JOptionPane.showInputDialog(null, "Route?",
                    "Show steps for a route: ", JOptionPane.QUESTION_MESSAGE, null, choices, choices[0]);
            try {
                Route r = log.findRoute(route);
                showRouteOnMap(r);
                printSteps(r);
            } catch (RouteNotFoundException e) {
                JOptionPane.showMessageDialog(null, "Not a valid route name...");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Log is empty");
        }
    }

    // EFFECTS: print out steps for given route
    private void printSteps(Route r) {
        JTextArea area = new JTextArea(20, 50);
        for (Step s : r.getSteps()) {
            String orderNum = Integer.toString(s.getOrderNum());
            area.append(orderNum + ". " + "Head " + s.getDirection() + " for "
                    + s.getDistance() + " metres on " + s.getStreetName());
            area.append("\n");
        }
        JOptionPane.showMessageDialog(null, area.getText());
    }

    // audio sample "bicycle_bell.wav" downloaded from https://www.wavsource.com/sfx/sfx.htm
    // MODIFIES: map
    // EFFECTS: shows route on map and plays sound of bicycle bell
    private void showRouteOnMap(Route r) {
        Tracker tracker = new Tracker(r);
        RoutePainter routePainter = new RoutePainter(tracker.getGeoPositions());
        map.setOverlayPainter(routePainter);
        playSound();
    }

    // EFFECTS: plays audio clip
    private void playSound() {
        try {
            AudioInputStream audioInputStream =
                    AudioSystem.getAudioInputStream(new File("data/bicycle_bell.wav").getAbsoluteFile());
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Cannot play sound");
        }
    }

    // Represents a listener for a menu
    private class ClickListener implements ActionListener {

        // EFFECTS: sets command to be on when "Show All" is clicked
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Show All")) {
                showAllRoutes();
            }
        }
    }

}
