package model;

import exceptions.DuplicateRouteNameException;
import exceptions.RouteNotFoundException;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

// Represents a manager of a collection of routes
public class RouteManager {
    List<Route> log = new ArrayList<>();

    // MODIFIES: this
    // EFFECTS: adds route to log, however, if given route has the same name as
    //          a route in the log manager, throw a DuplicateRouteNameException
    public void addRoute(Route r) throws DuplicateRouteNameException {
        for (Route next : log) {
            if (next.getName().equals(r.getName())) {
                throw new DuplicateRouteNameException();
            }
        }

        log.add(r);
    }

    // MODIFIES: this
    // EFFECTS: removes route from log
    public void removeRoute(Route r) {
        log.remove(r);
    }

    // EFFECTS: returns route with given name, otherwise throw exception
    public Route findRoute(String name) throws RouteNotFoundException {
        Route route = null;
        for (Route r : log) {
            if (r.getName().equals(name)) {
                route = r;
            }
        }
        if (route == null) {
            throw new RouteNotFoundException();
        } else {
            return route;
        }
    }


    // EFFECTS: returns size of log
    public int size() {
        return log.size();
    }

    // EFFECTS: returns list of routes
    public List<Route> getRoutes() {
        return log;
    }

    // Code from JsonSerializationDemo https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    // EFFECTS: returns routes in the Route Manager as a JSON array
    private JSONArray routesToJson() {
        JSONArray jsonArray = new JSONArray();

        for (Route r : log) {
            jsonArray.put(r.toJson());
        }

        return jsonArray;
    }

    // EFFECTS: returns route manager as a JSONObject
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("Routes",routesToJson());
        return json;
    }
}



