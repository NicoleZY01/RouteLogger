package model;

import org.json.JSONObject;

// Represents a step in a route
public class Step {
    int distance;
    String streetName;
    String direction; // one of: North, East, South, West
    int orderNum;

    // REQUIRES: distance > 0
    // EFFECTS: creates a step on a street with length distance in metres and sets the order number of step to 0
    public Step(String direction, int distance, String streetName) {
        this.direction = direction;
        this.distance = distance;
        this.streetName = streetName;
        this.orderNum = 0;
    }

    // EFFECTS: returns distance
    public int getDistance() {
        return distance;
    }

    // EFFECTS: returns direction
    public String getDirection() {
        return direction;
    }

    // EFFECTS: returns street name
    public String getStreetName() {
        return streetName;
    }

    // EFFECTS: returns order number of step
    public Integer getOrderNum() {
        return orderNum;
    }

    // MODIFIES: this
    // EFFECTS: changes order number to given number
    public void numberStep(Integer num) {
        this.orderNum = num;
    }

    // EFFECTS: returns step as a JSONObject
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("distance",distance);
        json.put("street name",streetName);
        json.put("direction",direction);
        return json;
    }
}
