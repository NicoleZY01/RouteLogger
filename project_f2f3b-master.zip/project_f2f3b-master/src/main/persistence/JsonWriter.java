package persistence;

import model.RouteManager;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

// Represents a writer that writes a route manager to a JSON file
// Code from JsonSerializationDemo at https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
public class JsonWriter {
    private PrintWriter writer;
    private String destination;

    // EFFECTS: Constructs writer to write to destination file
    public JsonWriter(String destination) {
        this.destination = destination;
    }

    // MODIFIES: this
    // EFFECTS: opens writer; throws FileNotFoundException if destination file cannot
    // be opened for writing
    public void open() throws FileNotFoundException {
        writer = new PrintWriter(new File(destination));
    }

    // MODIFIES: this
    // EFFECTS: closes writer; throws FileNotFoundException if destination file cannot
    // be found
    public void close() throws FileNotFoundException {
        writer.close();
    }

    // MODIFIES: this
    // EFFECTS: writes JSON representation of RouteManager to file
    public void write(RouteManager lr) {
        JSONObject json = lr.toJson();
        saveToFile(json);
    }

    // MODIFIES: this
    // EFFECTS: writes JSONObject to file
    private void saveToFile(JSONObject json) {
        writer.print(json);
    }


}
