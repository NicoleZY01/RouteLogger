package ui;

import model.RouteManager;

import javax.swing.*;

// Represents an app command
public abstract class Command {
    protected JMenuItem menuItem;
    protected RouteManager log;

    // EFFECTS: constructs a command
    public Command(String s, JMenu menu, RouteLogApp app) {
        menuItem = new JMenuItem(s);
        addToMenu(menu);
        this.log = app.getLog();
    }


    // EFFECTS: adds listener to command
    protected abstract void addListener();

    // EFFECTS: adds item to the menu
    public void addToMenu(JMenu menu) {
        menu.add(menuItem);
    }

    // EFFECTS: returns a route manager
    public RouteManager getLog() {
        return log;
    }

    // MODIFIES: this
    // EFFECTS: removes menu item from menu
    public void removeMenuItem(JMenu menu) {
        menu.remove(menuItem);
    }

}
