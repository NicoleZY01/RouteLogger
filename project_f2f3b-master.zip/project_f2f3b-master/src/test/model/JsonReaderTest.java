package model;

import exceptions.DuplicateRouteNameException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import persistence.JsonReader;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class JsonReaderTest {

    @Test
    public void testNoFileFound() throws DuplicateRouteNameException {
        try {
            JsonReader reader = new JsonReader("./data/nothing.json");
            reader.read();
            fail("FileNotFoundException never thrown");
        } catch (IOException e) {
            //
        }
    }

    @Test
    public void testFileFound() throws DuplicateRouteNameException {
        try {
            JsonReader jsonReader = new JsonReader("./data/testworkingmanager.json");
            jsonReader.read();
        } catch (IOException e) {
            fail("FileNotFoundException thrown");
        }
    }

    @Test
    public void emptyRouteManager() throws DuplicateRouteNameException {
        try {
            JsonReader jsonReader = new JsonReader("./data/testemptymanager.json");
            RouteManager rm = jsonReader.read();
            assertEquals(0,rm.size());
        } catch (IOException e) {
            fail("FileNotFoundException thrown");
        }
    }

    @Test
    public void oldRouteManager() throws DuplicateRouteNameException {
        try {
            JsonReader jsonReader = new JsonReader("./data/testworkingmanager.json");
            RouteManager rm = jsonReader.read();
            assertEquals(2,rm.size());
        } catch (IOException e) {
            fail("FileNotFoundException thrown");
        }
    }
}
