package ui;

import model.Route;
import model.Step;
import org.jxmapviewer.viewer.GeoPosition;

import java.util.ArrayList;
import java.util.List;

// Represents a list of geopositions in a route
public class Tracker {
    private static final double RADIUS_OF_EARTH = 6378000;
    List<GeoPosition> geoPositions;

    // MODIFIES: this
    // EFFECTS: constructs a tracker from a given route
    public Tracker(Route route) {
        geoPositions = new ArrayList<>();
        geoPositions.add(route.getStart());
        addNewGeoPositions(route);
    }

    // MODIFIES: this
    // EFFECTS: adds geopositions from route to tracker
    public void addNewGeoPositions(Route route) {
        int i = 0;
        for (Step s : route.getSteps()) {
            GeoPosition oldPosition = geoPositions.get(i);
            geoPositions.add(createGeoPosition(oldPosition,s));
            i += 1;
        }
    }

    // Calculations for new geopositions from
    // https://stackoverflow.com/questions/7477003/calculating-new-longitude-latitude-from-old-n-meters
    // EFFECTS: returns a geoposition from step
    public GeoPosition createGeoPosition(GeoPosition geoPosition, Step s) {
        double newLatitude = geoPosition.getLatitude();
        double newLongitude = geoPosition.getLongitude();

        switch (s.getDirection()) {
            case "north":
                newLatitude += (s.getDistance() / RADIUS_OF_EARTH) * (180 / Math.PI);
                break;
            case "south":
                newLatitude -= (s.getDistance() / RADIUS_OF_EARTH) * (180 / Math.PI);
                break;
            case "east":
                newLongitude += (s.getDistance() / RADIUS_OF_EARTH) * (180 / Math.PI)
                        / Math.cos(newLatitude * Math.PI / 180);
                break;
            default:
                newLongitude -= (s.getDistance() / RADIUS_OF_EARTH) * (180 / Math.PI)
                        / Math.cos(newLatitude * Math.PI / 180);
                break;
        }

        return new GeoPosition(newLatitude,newLongitude);
    }

    // EFFECTS: returns list of geopositions
    public List<GeoPosition> getGeoPositions() {
        return geoPositions;
    }
}
