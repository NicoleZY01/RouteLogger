package ui;

import exceptions.RouteNotFoundException;
import model.Route;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

// Represents a command to find route length
public class FindRouteLengthCommand extends Command {
    ClickListener listener;

    // EFFECTS: constructs a command for finding route length
    public FindRouteLengthCommand(JMenu menu, RouteLogApp app) {
        super("Find Length", menu, app);
        listener = new ClickListener();
        addListener();
    }

    // MODIFIES: this
    // EFFECTS: adds a listener to the menu
    @Override
    protected void addListener() {
        menuItem.addActionListener(listener);
    }


    private class ClickListener implements ActionListener {

        // EFFECTS: sets command to be on when "Find Length" is clicked
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Find Length")) {
                findLengthMenu();
            }
        }
    }

    // EFFECTS: constructs an option pane to select a route
    private void findLengthMenu() {
        List<String> list = new ArrayList<>();
        for (Route r : log.getRoutes()) {
            list.add(r.getName());
        }
        Object[] choices = list.toArray();
        String route = (String) JOptionPane.showInputDialog(null, "Route?",
                "Find length for route: ", JOptionPane.QUESTION_MESSAGE, null, choices, choices[0]);
        routeDistance(route);
    }

    // EFFECTS: prints length of route in metres
    private void routeDistance(String name) {
        int distance = 0;
        try {
            Route r = log.findRoute(name);
            distance = r.length();
        } catch (RouteNotFoundException e) {
            JOptionPane.showMessageDialog(null,"Not a valid route name...");
        }
        String stringDistance = Integer.toString(distance);
        JOptionPane.showMessageDialog(null, stringDistance + " metres");
    }
}
