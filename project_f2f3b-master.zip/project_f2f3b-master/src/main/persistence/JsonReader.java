package persistence;

import exceptions.DuplicateRouteNameException;
import model.Route;
import model.RouteManager;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jxmapviewer.viewer.GeoPosition;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

// Represents a reader that reads a RouteManager from a JSON file
public class JsonReader {
    private String source;

    // Code from JsonSerializationDemo at https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    // EFFECTS: constructs reader to read from source file
    public JsonReader(String source) {
        this.source = source;
    }

    // Code from JsonSerializationDemo at https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    // EFFECTS: reads source file as string and returns it
    private String readFile(String source) throws IOException {
        StringBuilder contentBuilder = new StringBuilder();

        try (Stream<String> stream = Files.lines(Paths.get(source), StandardCharsets.UTF_8)) {
            stream.forEach(s -> contentBuilder.append(s));
        }

        return contentBuilder.toString();
    }

    // Code from JsonSerializationDemo at https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    // EFFECTS: reads RouteManager from file and returns it
    public RouteManager read() throws IOException, DuplicateRouteNameException {
        String reader = readFile(source);
        JSONObject json = new JSONObject(reader);
        return parseRouteManager(json);

    }

    // Code from JsonSerializationDemo at https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
    // EFFECTS: parses route manager from JSONObject and returns it
    private RouteManager parseRouteManager(JSONObject json) throws DuplicateRouteNameException {
        RouteManager lr = new RouteManager();
        addOldRoutes(lr,json);
        return lr;
    }

    // EFFECTS: parses routes from JSONObject and adds them to RouteManager
    private void addOldRoutes(RouteManager lr, JSONObject json) throws DuplicateRouteNameException {
        JSONArray array = json.getJSONArray("Routes");
        for (Object j : array) {
            JSONObject js = (JSONObject) j;
            addOldRoute(lr,js);
        }

    }

    // EFFECTS: parses a route from JSONObject and adds it to RouteManager
    private void addOldRoute(RouteManager lr, JSONObject js) throws DuplicateRouteNameException {
        String name = js.getString("name");
        Route r = new Route(name, addOldStart(js.getJSONObject("start")));
        JSONArray json = js.getJSONArray("steps");
        addOldSteps(r,json);
        lr.addRoute(r);
    }

    // EFFECTS: parses steps from JSONArray and adds them to Route
    private void addOldSteps(Route r, JSONArray js) {
        for (Object j : js) {
            JSONObject json = (JSONObject) j;
            addOldStep(r, json);
        }
    }

    // EFFECTS: gets direction, distance, and street name from JSONObject and adds them to Route
    private void addOldStep(Route r,JSONObject j) {
        String dir = j.getString("direction");
        int dist = j.getInt("distance");
        String streetName = j.getString("street name");

        r.addStep(dir,dist,streetName);
    }

    // EFFECTS: gets latitude and longitude from JSONObject and returns a GeoPosition
    private GeoPosition addOldStart(JSONObject js) {
        double lat = js.getDouble("latitude");
        double longitude = js.getDouble("longitude");

        return new GeoPosition(lat, longitude);
    }

}
