package ui;

// Represents the main program
public class Main {
    public static void main(String[] args) {
        new RouteLogApp();
    }
}
