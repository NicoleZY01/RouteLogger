package ui;

import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.viewer.GeoPosition;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

// Represents the origin point of a route
public class Origin {
    JXMapViewer map;
    GeoPosition start;
    ClickListener clickListener;
    boolean clicked;

    // MODIFIES: this
    // EFFECTS: constructs a route tracker
    public Origin(JXMapViewer map) {
        this.map = map;
        clickListener = new ClickListener();
        map.addMouseListener(clickListener);
        clicked = false;
    }

    // EFFECTS: if the mouse is clicked on the map, then the route tracker will set an origin at that point
    private class ClickListener extends MouseAdapter {
        public void mouseClicked(MouseEvent e) {
            if (!clicked) {
                if (e.getClickCount() == 1 && e.getButton() == MouseEvent.BUTTON1) {
                    clicked = true;
                    java.awt.Point p = e.getPoint();
                    GeoPosition geo = map.convertPointToGeoPosition(p);
                    setStart(geo);
                }
            }
        }
    }

    // MODIFIES: this
    // EFFECTS: sets the origin to a given geoposition
    private void setStart(GeoPosition geoPosition) {
        this.start = geoPosition;
        map.removeMouseListener(clickListener);
    }

    // EFFECTS: returns the origin point
    public GeoPosition getStart() {
        return start;
    }



}
