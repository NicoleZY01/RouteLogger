package ui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Represents a command to quit the app
public class QuitCommand extends Command {
    ClickListener clickListener;

    // EFFECTS: constructs a command to quit from a menu and route manager
    public QuitCommand(JMenu menu, RouteLogApp app) {
        super("Quit", menu, app);
        clickListener = new ClickListener();
        addListener();
    }

    // MODIFIES: this
    // EFFECTS: adds a listener to the command
    @Override
    protected void addListener() {
        menuItem.addActionListener(clickListener);
    }

    // Represents a listener for the command
    private class ClickListener implements ActionListener {

        // EFFECTS: quits the app when "Quit" is clicked
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Quit")) {
                System.exit(0);
            }
        }
    }

}
