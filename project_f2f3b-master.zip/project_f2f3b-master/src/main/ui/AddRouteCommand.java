package ui;

import exceptions.DuplicateRouteNameException;
import model.Route;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.viewer.GeoPosition;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Represents a command to add a route
public class AddRouteCommand extends Command {
    ClickListener listener;
    OriginListener originListener;
    DoneListener doneListener;
    JMenu originMenu;
    JMenuItem setOrigin;
    JMenuItem done;
    GeoPosition start;
    JXMapViewer mapViewer;
    Origin origin;
    Map map;

    // EFFECTS: constructs a command for add route
    public AddRouteCommand(JMenu menu, RouteLogApp app, JMenu originMenu, Map map) {
        super("Add Route", menu, app);
        this.map = map;
        this.mapViewer = map.getMapViewer();
        listener = new ClickListener();
        this.originMenu = originMenu;
        this.setOrigin = originMenu.getItem(0);
        this.done = originMenu.getItem(1);
        addListener();
    }

    // MODIFIES: this
    // EFFECTS: adds a listener to the menu
    @Override
    protected void addListener() {
        menuItem.addActionListener(listener);
        doneListener = new DoneListener();
        originListener = new OriginListener();
    }

    // MODIFIES: log
    // EFFECTS: creates a route and adds it to log
    private void createRoute() throws DuplicateRouteNameException {
        String name = JOptionPane.showInputDialog("Enter route name: ");
        if (!name.equals("")) {
            Route r = new Route(name, start);
            boolean doneStep = false;
            while (!doneStep) {
                addNewStep(r);
                int result = JOptionPane.showConfirmDialog(null, null,
                        "Done adding steps?: ", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    doneStep = true;
                }
            }

            log.addRoute(r);
            map.createMouseInteractions();
            done.removeActionListener(doneListener);
            setOrigin.removeActionListener(originListener);
        } else {
            JOptionPane.showMessageDialog(null,"Must give route a name...");
        }
    }

    // Referenced multi-input JOptionPane code from
    // https://stackoverflow.com/questions/6555040/multiple-input-in-joptionpane-showinputdialog/6555051
    // EFFECTS: adds direction to route
    private void addNewStep(Route r) {
        JTextField dirField = new JTextField(5);
        JTextField strField = new JTextField(20);
        JTextField distField = new JTextField(20);

        JPanel stepPanel = new JPanel();
        stepPanel.add(new JLabel("Direction (north/south/east/west): "));
        stepPanel.add(dirField);
        stepPanel.add(new JLabel("Street Name: "));
        stepPanel.add(strField);
        stepPanel.add(new JLabel("Distance (metres): "));
        stepPanel.add(distField);

        int result = JOptionPane.showConfirmDialog(null, stepPanel, "Please enter a new step: ",
                JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            int dist = Integer.parseInt(distField.getText());
            r.addStep(dirField.getText().toLowerCase(), dist, strField.getText());
        }
    }

    // EFFECTS: makes set origin menu visible
    private void makeSetOriginVisible() {
        JOptionPane.showMessageDialog(null, "Click and drag mouse to move across the map."
                + " Zoom in and out using your mouse wheel. "
                + " Once you have found your starting point, go to Origin menu and click Set Origin."
                + " Click on the map to set the origin, then go to Origin menu and click Done.");

        setOrigin.addActionListener(originListener);
        done.addActionListener(doneListener);
        originMenu.setVisible(true);
    }

    // MODIFIES: this
    // EFFECTS: creates an origin
    private void createOrigin() {
        map.removeMouseInteractions();
        this.origin = new Origin(mapViewer);
        done.setVisible(true);
    }

    // MODIFIES: this
    // EFFECTS: sets the start to geoposition of origin
    private void setOrigin(Origin o) throws DuplicateRouteNameException {
        this.start = o.getStart();
        createRoute();
    }

    // Represents a listener for the command
    private class ClickListener implements ActionListener {

        // EFFECTS: sets command to be on when "Add Route" is clicked
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Add Route")) {
                makeSetOriginVisible();
            }
        }
    }

    // Represents a listener for the set origin menu
    private class OriginListener implements ActionListener {

        // EFFECTS: sets command to be on when "Set Origin" is clicked
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Set Origin")) {
                setOrigin.setVisible(false);
                createOrigin();
            }
        }
    }

    // Represents a listener for the command
    private class DoneListener implements ActionListener {

        // EFFECTS: if the route name is unique, sets command to be on when "Done" is clicked
        //          if the route name is not unique, throws a duplicate name exception
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Done")) {
                try {
                    done.setVisible(false);
                    setOrigin.setVisible(true);
                    originMenu.setVisible(false);
                    setOrigin(origin);
                } catch (DuplicateRouteNameException exception) {
                    JOptionPane.showMessageDialog(null, "Cannot have route with the same name");
                }
            }
        }
    }

}
