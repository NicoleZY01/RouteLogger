package exceptions;

// Represents an exception to indicate that route name cannot be found
public class RouteNotFoundException extends Exception {

    // EFFECTS: constructs a route not found exception
    public RouteNotFoundException() {
        super();
    }
}
