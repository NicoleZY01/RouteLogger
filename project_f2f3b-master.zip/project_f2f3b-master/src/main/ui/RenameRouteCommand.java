package ui;

import exceptions.RouteNotFoundException;
import model.Route;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Represents a command to rename a route
public class RenameRouteCommand extends Command {
    ClickListener listener;

    // EFFECTS: constructs a command to rename route
    public RenameRouteCommand(JMenu menu, RouteLogApp app) {
        super("Rename Route", menu, app);
        listener = new ClickListener();
        addListener();
    }

    // MODIFIES: this
    // EFFECTS: adds a listener to the menu
    @Override
    protected void addListener() {
        menuItem.addActionListener(listener);
    }

    // Represents a listener for a menu
    private class ClickListener implements ActionListener {

        // EFFECTS: sets command to be on when "Rename Route" is clicked
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Rename Route")) {
                renameRoute();
            }
        }
    }

    // MODIFIES: route
    // EFFECTS: renames route in log
    private void renameRoute() {
        String name = JOptionPane.showInputDialog("Enter route name to change: ");
        try {
            Route r = log.findRoute(name);
            String newName = JOptionPane.showInputDialog("Enter new name: ");
            r.renameRoute(newName);
        } catch (RouteNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Route name not found...");
        }

    }

}
