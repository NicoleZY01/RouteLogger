package model;

import exceptions.DuplicateRouteNameException;
import org.junit.jupiter.api.Test;
import org.jxmapviewer.viewer.GeoPosition;
import persistence.JsonReader;
import persistence.JsonWriter;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class JsonWriterTest {
    private JsonWriter jsonWriter;
    private JsonReader jsonReader;

    @Test
    public void testWriteBadFile() {
        try {
            RouteManager rm = new RouteManager();
            jsonWriter = new JsonWriter("./data\nothing.json");
            jsonWriter.open();
            fail("IOException not thrown");
        } catch (IOException e){
            //
        }
    }

    @Test
    public void testWriteToEmptyFile() throws DuplicateRouteNameException {
        try {
            RouteManager rm = new RouteManager();
            jsonWriter = new JsonWriter("./data/testmanager.json");
            jsonWriter.open();
            jsonWriter.write(rm);
            jsonWriter.close();

            jsonReader = new JsonReader("./data/testmanager.json");
            rm = jsonReader.read();
            assertEquals(0,rm.size());
        } catch (IOException e){
            fail("IOException not thrown");
        }
    }

    @Test
    public void testWriteToFile() {
        try {
            RouteManager rm = new RouteManager();
            Route r1 = new Route("Route 1", new GeoPosition(0, 0));
            r1.addStep("North",5000,"Lynn Canyon");
            r1.addStep("East",561,"East Mall");

            Route r2 = new Route("Route 2", new GeoPosition(0, 0));
            r2.addStep("North",5000,"North Road");
            r2.addStep("East",561,"Smith Avenue");
            rm.addRoute(r1);
            rm.addRoute(r2);

            jsonWriter = new JsonWriter("./data/testworkingmanager.json");
            jsonWriter.open();
            jsonWriter.write(rm);
            jsonWriter.close();

            jsonReader = new JsonReader("./data/testworkingmanager.json");
            rm = jsonReader.read();
            assertEquals(2,rm.size());
            assertEquals(2,rm.getRoutes().size());
        } catch (IOException e) {
            fail("IOException thrown");
        } catch (DuplicateRouteNameException e) {
            fail("DuplicateRouteNameException thrown");
        }
    }
}
