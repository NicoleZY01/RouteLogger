package exceptions;

// Represents an exception to indicate duplicate route name being added
public class DuplicateRouteNameException extends Exception {

    // EFFECTS: constructs a duplicate route name exception
    public DuplicateRouteNameException() {
        super();
    }
}
