package ui;

import exceptions.RouteNotFoundException;
import model.Route;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Represents a command to delete route
public class DeleteRouteCommand extends Command {
    ClickListener listener;

    // EFFECTS: constructs a command for delete route
    public DeleteRouteCommand(JMenu menu, RouteLogApp app) {
        super("Delete Route", menu, app);
        listener = new ClickListener();
        addListener();
    }

    // MODIFIES: this
    // EFFECTS: adds listener to menu
    @Override
    protected void addListener() {
        menuItem.addActionListener(listener);
    }

    // Represents a listener for a menu
    private class ClickListener implements ActionListener {
        // EFFECTS: set command to be on when "Delete Route" is clicked
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Delete Route")) {
                deleteRoute();
            }
        }
    }

    // MODIFIES: this
    // EFFECTS: deletes route with given name
    private void deleteRoute() {
        String name = JOptionPane.showInputDialog("Enter name of route to delete: ");
        try {
            Route r = log.findRoute(name);
            log.removeRoute(r);
        } catch (RouteNotFoundException e) {
            JOptionPane.showMessageDialog(null,"Not a valid route name...");
        }
    }
}


